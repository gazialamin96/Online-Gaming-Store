<?php
     require_once 'cart.php';
     $obj_cart->new Cart();
     $page = product_details.php;


?>