<?php
     require_once 'database.php';

     class Application{
     	public function __construct(){
     		$obj = new Database();
     	}
     	
     	    
       
     }


?>