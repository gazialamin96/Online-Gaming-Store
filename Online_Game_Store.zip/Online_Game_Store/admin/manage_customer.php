<?php
    $page = 'manage_customer_info.php';
    include './dashboard.php';

?>