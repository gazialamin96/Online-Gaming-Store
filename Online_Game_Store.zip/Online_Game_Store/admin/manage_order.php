<?php
    $page = 'manage_order_info.php';
    include './dashboard.php';

?>