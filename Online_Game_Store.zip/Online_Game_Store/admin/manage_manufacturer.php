<?php
    $page = 'manage_manufacturer_info.php';
    include './dashboard.php';

?>
