<?php 
    $product_id=$_GET['id'];
    $page = 'edit_product_form.php';
    include 'dashboard.php';

?>