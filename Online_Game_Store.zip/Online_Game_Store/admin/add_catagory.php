<?php
    $page = 'add_catagory_form.php';
    include 'dashboard.php';