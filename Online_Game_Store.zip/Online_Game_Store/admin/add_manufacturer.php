<?php
    $page = 'add_manufacturer_form.php';
    include 'dashboard.php';
    ?>