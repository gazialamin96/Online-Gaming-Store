<?php

if (isset($_GET['shipid'])) {
   	$shipid = $_GET['shipid'];
    $query_result = $obj_admin->all_order_itms($shipid);
   }

?>


<ul class="breadcrumb">
				<li>
					<i class="icon-home"></i>
					<a href="index-2.html">Home</a> 
					<i class="icon-angle-right"></i>
				</li>
				<li><a href="#">Tables</a></li>
			</ul>

			<div class="row-fluid sortable">		
				<div class="box span12">
					<div class="box-header" data-original-title>
						<h2><i class="halflings-icon user"></i><span class="break"></span>
						Order 
					Products </h2>
						<div class="box-icon">
							<a href="#" class="btn-setting"><i class="halflings-icon wrench"></i></a>
							<a href="#" class="btn-minimize"><i class="halflings-icon chevron-up"></i></a>
							<a href="#" class="btn-close"><i class="halflings-icon remove"></i></a>
						</div>
					</div>
					<div class="box-content">
						<table class="table table-striped table-bordered bootstrap-datatable datatable">
						  <thead>
							  <tr>
								  <th>Product ID</th>
								  <th>Product Name</th>
								  <th>Product Price</th>
								  <th>Product Quantity</th>
								
							  </tr>
						  </thead>   
						  <tbody>
						  	<?php
                                while($row = mysql_fetch_assoc($query_result)) {
                                	
                                
						  	?>
							<tr>
								<td><?php echo $row['product_id'] ?></td>
								<td class="center"><?php echo $row['product_name'] ?></td>
							    <td class="center"><?php echo $row['product_price'] ?></td>
							    <td class="center"><?php echo $row['quantity'] ?></td>
							   
							    
									
								
							</tr>
							<?php }?>
						
						  </tbody>
					  </table>            
					</div>
				</div><!--/span-->
			
			</div><!--/row-->
