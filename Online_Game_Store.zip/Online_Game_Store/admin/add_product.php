<?php
    $page = 'add_product_form.php';
    include './dashboard.php'; 


?>