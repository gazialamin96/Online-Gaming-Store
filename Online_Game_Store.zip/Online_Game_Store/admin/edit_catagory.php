<?php 
    $catagory_id=$_GET['id'];
    $page = 'edit_catagory_form.php';
    include 'dashboard.php';

?>