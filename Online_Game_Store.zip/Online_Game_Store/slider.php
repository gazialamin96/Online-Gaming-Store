
			<!--content-->
			<div class="page_content_offset">
				<div class="container">
					<!--banners-->
					<section class="row clearfix">
						<div class="col-lg-6 col-md-6 col-sm-6 m_bottom_50 m_sm_bottom_35">
							<a href="#" class="d_block banner animate_ftr wrapper r_corners relative m_xs_bottom_30">
								<img src="asset/frontend/images/banner_img_1.png" alt="">
								<span class="banner_caption d_block vc_child t_align_c w_sm_auto">
									<span class="d_inline_middle">
										<span class="d_block scheme_color banner_title type_2 m_bottom_5 m_mxs_bottom_5"><b>-20%</b></span>
										<span class="d_block divider_type_2 centered_db m_bottom_5 d_sm_none"></span>
										<span class="d_block color_light tt_uppercase m_bottom_15 banner_title_3 m_md_bottom_5 d_mxs_none">On All<br><b>Mouses</b></span>
									<!-- 	<span class="button_type_6 bg_dark_color tt_uppercase r_corners color_light d_inline_b tr_all_hover box_s_none f_size_ex_large">Shop Now!</span> -->
									</span>
								</span>
							</a>
						</div>

						<div class="col-lg-6 col-md-6 col-sm-6 m_bottom_50 m_sm_bottom_35">
							<a href="#" class="d_block banner animate_ftr wrapper r_corners type_2 relative">
								<img src="asset/frontend/images/banner_img_2.png" alt="">
								<span class="banner_caption d_block vc_child t_align_c w_sm_auto">
									<span class="d_inline_middle">
										<span class="d_block scheme_color banner_title type_2 m_bottom_5 m_mxs_bottom_5"><b>-50%</b></span>
										<span class="d_block divider_type_2 centered_db m_bottom_5 d_sm_none"></span>
										<span class="d_block color_light tt_uppercase m_bottom_15 banner_title_3 m_md_bottom_5 d_mxs_none">On All<br><b>Mouses</b></span>
									<!-- 	<span class="button_type_6 bg_dark_color tt_uppercase r_corners color_light d_inline_b tr_all_hover box_s_none f_size_ex_large">Shop Now!</span> -->
									</span>
								</span>
							</a>
						</div>
					</section>
