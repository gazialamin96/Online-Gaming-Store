-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 19, 2018 at 05:44 PM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.6.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ecommerce`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product`
--

CREATE TABLE `tbl_product` (
  `product_id` int(6) NOT NULL,
  `catagory_id` int(3) NOT NULL,
  `manufacturer_id` int(3) NOT NULL,
  `product_name` varchar(51) NOT NULL,
  `product_price` float NOT NULL,
  `product_quantity` int(4) NOT NULL,
  `product_sku` varchar(5) NOT NULL,
  `product_short_description` text NOT NULL,
  `product_long_description` text NOT NULL,
  `product_image` varchar(100) NOT NULL,
  `publication_status` tinyint(1) NOT NULL,
  `deletion_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_product`
--

INSERT INTO `tbl_product` (`product_id`, `catagory_id`, `manufacturer_id`, `product_name`, `product_price`, `product_quantity`, `product_sku`, `product_short_description`, `product_long_description`, `product_image`, `publication_status`, `deletion_status`) VALUES
(23, 18, 12, 'PS4', 40000, 5, 'mklp', 'short', 'long', 'product_images/playstation-4-dualshock-4-playstation-camera-one-column-01-ps4-us-05oct17.png', 1, 0),
(25, 6, 15, 'Logitech Keyboard', 300, 6, 'lkjh', 'short', 'long', 'product_images/v.jpg', 1, 0),
(32, 13, 6, 'Samsung Monitor', 69888, 70, 'qwert', 's', 'l', 'product_images/0050124_0.jpeg', 1, 0),
(34, 17, 11, 'Computer Led Ram', 3700, 16, 'assss', 's', 'l', 'product_images/Corsair-Vengeance-RGB-LED-RAM.jpg', 1, 0),
(35, 5, 5, 'Dell Laptop', 28000, 5, 'kkjj', '.................', '.............................................', 'product_images/5289-1_thumb800.jpg', 1, 0),
(37, 5, 5, 'Dell Laptop', 32000, 4, 'llll', '.............', '...............................', 'product_images/item_XL_10158323_12732480.jpg', 1, 0),
(38, 5, 5, 'Dell Laptop', 64000, 16, 'oip', '...............', '...............................', 'product_images/item_XL_17512662_23868657.jpg', 1, 0),
(41, 5, 5, 'Dell Laptop', 31000, 11, 'vvvv', '............', '.......................', 'product_images/Dell-Studio-14z_large.jpg', 1, 0),
(42, 5, 5, 'Dell Laptop', 44000, 78, 'jjjj', '.............', '...............................', 'product_images/4300.jpg', 1, 0),
(43, 5, 5, 'Dell Laptop', 56000, 6, 'hjhjh', '............', '............................', 'product_images/Dell_laptop_349.jpg', 1, 0),
(44, 5, 5, 'Dell Laptop', 10000, 19, 'aaaaa', '..............', '.............................', 'product_images/Del.jpg', 1, 0),
(45, 5, 5, 'Dell Laptop', 66000, 77, 'lpoi', '.............', '....................', 'product_images/lenovoflexpad_big.jpg', 1, 0),
(46, 5, 5, 'Dell Laptop', 23000, 44, 'lllll', '.............', '...........................', 'product_images/x260-38id.png', 1, 0),
(63, 6, 15, 'Led Keyboard', 9800, 78, 'dnvon', '..............................', '..............................', 'product_images/led-keyboard_1505144096359_10816625_ver1.0.jpg', 1, 0),
(64, 6, 15, 'Led Keyboard', 3333, 34, 'rrrrr', '......................', '.........................', 'product_images/r.jpg', 1, 0),
(65, 6, 15, 'Led Keyboard', 3566, 12, 'jhgf', '..............', '......................', 'product_images/s-l1000.jpg', 1, 0),
(66, 6, 15, 'Led Keyboard', 6547, 14, 'loiu', '...............', '.......................', 'product_images/kb-003_original.jpg', 1, 0),
(67, 6, 15, 'Led Keyboard', 4100, 22, 'hytr', '............', '................', 'product_images/_SKU133376tongyong (7).jpg', 1, 0),
(69, 6, 15, 'Led Keyboard', 2300, 36, 'lkjhp', '...............', '................', 'product_images/HAVIT-Rainbow-Backlit-Wired-Gaming-Keyboard-and-Mouse-Combo-Black-2016-Model-0-5.jpg', 1, 0),
(70, 6, 15, 'Led Keyboard', 980, 17, 'plkjh', '............', '.....................', 'product_images/hv-kb558cm-gaming-keyboard-mouse-combo-4.jpg', 1, 0),
(71, 6, 15, 'Led Keyboard', 1500, 11, 'qwerm', '...............', '.................', 'product_images/kb-003_original.jpg', 1, 0),
(72, 6, 15, 'Led Keyboard', 1200, 11, 'abcde', '...................', '........................', 'product_images/s-l1000.jpg', 1, 0),
(73, 7, 8, '16 GB Pendrive', 450, 23, 'qaz', '................', '.......................', 'product_images/51GxPs-FNKL._SL1000_.jpg', 1, 0),
(74, 7, 8, '32 GB Pendrive', 1000, 14, 'kjla', '...............', '.............................', 'product_images/71-9eP+yh6L._SL1500_.jpg', 1, 0),
(75, 7, 8, '32 GB Pendrive', 1200, 13, 'sssa', '......................', '....................', 'product_images/615whLfGL4L._SY355_.jpg', 1, 0),
(76, 7, 8, '16 GB Pendrive', 700, 9, 'rtrt', '.....................', '...................', 'product_images/3044_19.jpg', 1, 0),
(77, 7, 8, '32 GB Pendrive', 1200, 3, 'mnb', '...........', '......................', 'product_images/5197208wZ2L._SL1000_.jpg', 1, 0),
(78, 7, 8, '16 GB Pendrive', 750, 12, 'eeee', '....................', '....................', 'product_images/925839215s.jpg', 1, 0),
(79, 7, 8, '8 GB Pendrive', 455, 13, 'dsa', '.............', '...........', 'product_images/740617222401_L.jpg', 1, 0),
(80, 7, 8, '8 GB Pendrive', 550, 12, 'ddddd', '.....................', '.......................', 'product_images/best_pendrive_usb3_flashdrive1.jpg', 1, 0),
(81, 7, 8, '4 GB Pendrive', 350, 4, 'fffff', '...................', '............................', 'product_images/product_29-500x500.jpg', 1, 0),
(82, 9, 16, '1600mah Power Bank', 3000, 23, 'az', '...............................', '.............................', 'product_images/61PrA8JLREL._SX425_.jpg', 1, 0),
(83, 9, 16, '1600mah Power Bank', 2300, 22, 'werq', '....................', '.......................', 'product_images/power-bank-8000-mah--MO8839-19--hd.jpg', 1, 0),
(84, 9, 16, '1600mah Power Bank', 2500, 2, 'derw', '......................', '............................', 'product_images/powerflat-punainen.jpg', 1, 0),
(85, 9, 16, '3200mah Power Bank', 6500, 3, 'dddf', '..................', '.................', 'product_images/21946_xl.jpg', 1, 0),
(86, 9, 16, '3200mah Power Bank', 6000, 32, 'fder', '..........', '.....................', 'product_images/hd-power-bank-battery-motion-detection-spy-camera-2-.jpg', 1, 0),
(90, 9, 16, '1600mah Power Bank', 3200, 453, 'dbn', '.....................', '..........................', 'product_images/suich-power-banks.jpg', 1, 0),
(92, 9, 16, '1600mah Power Bank', 2200, 43, 'dgh', '.................', '....................', 'product_images/as.jpg', 1, 0),
(93, 9, 16, '1800mah Power Bank', 3300, 0, '', 'nnnnnnnn', 'nnnnnnnnnnnnnnnnnnnnnnnn', 'product_images/cs.jpg', 1, 0),
(95, 9, 16, '1800mah Power Bank', 2365, 13, 'fdsgr', '.................', '..................', 'product_images/qw.jpg', 1, 0),
(97, 10, 17, 'Creative Speaker', 4322, 43, 'dt', '............', '...................', 'product_images/71B558HgE+L._SL1500_.jpg', 1, 0),
(99, 10, 17, 'Creative Speaker', 4300, 2, 'dewq', '.............', '...................', 'product_images/71C1zQH2G+L._SL1500_.jpg', 1, 0),
(100, 10, 17, 'Creative Speaker', 2400, 3, 'vc', '..............', '...................', 'product_images/867279-Edifier M1370BT Home Audio Speakers Bluetooth-l.jpg', 1, 0),
(101, 10, 17, 'Creative Speaker', 6500, 4, 'ft', '..............', '', 'product_images/creative-inspire-t3000.716941.jpg', 1, 0),
(102, 10, 17, 'Creative Speaker', 4700, 5, 'frt', '.................', '....................', 'product_images/Creative-Speakers-680x425.jpg', 1, 0),
(103, 10, 17, 'Creative Speaker', 4450, 6, 'ui', '...............', '..................', 'product_images/hero-creative-t4-wireless.jpg', 1, 0),
(104, 10, 17, 'Creative Speaker', 2300, 2, 'kli', '..............', '.........................', 'product_images/Inspire_A200_c.jpg', 1, 0),
(105, 10, 17, 'Creative Speaker', 3100, 8, 'lp', '..................', '...............', 'product_images/dav-tz215-1.jpeg', 1, 0),
(106, 10, 17, 'Creative Speaker', 2100, 8, 'bvc', '...............', '..............', 'product_images/LHD627-600x600.jpg', 1, 0),
(107, 13, 6, '24" LED Monitor', 31500, 9, 'fda', '..............', '..............', 'product_images/91nHqZL6TYL._SL1500_.jpg', 1, 0),
(108, 13, 6, '24" LED Monitor', 54000, 7, 'vsa', '.............', '.................', 'product_images/medium01.jpg', 1, 0),
(109, 13, 6, '24" LED Monitor', 43500, 14, 'aqw', '......................', '........................', 'product_images/281.jpg', 1, 0),
(110, 13, 6, '24" LED Monitor', 22000, 23, 're', '....................', '..........................', 'product_images/s-l640.jpg', 1, 0),
(111, 13, 6, '24" LED Monitor', 65400, 87, 'cdf', '.................', '...................', 'product_images/u_10157851.jpg', 1, 0),
(112, 13, 6, '22" LED Monitor', 28900, 19, 'vbh', '.................', '................', 'product_images/ASUS PG279Q_1-600x600.jpg', 1, 0),
(113, 13, 6, '22" LED Monitor', 36900, 98, 'jk', '.........................', '......................', 'product_images/Pdpdefault-ls27d590cs-za-600x600-C1-052016.jpg', 1, 0),
(114, 13, 6, '22" LED Monitor', 58900, 56, 'derg', '.........................', '..................', 'product_images/l27000whs_hero-15.jpg', 1, 0),
(116, 14, 13, 'Optical Mouse', 1200, 6, 'cft', '........................', '.....................', 'product_images/1465367762612196.jpg', 1, 0),
(118, 14, 13, 'Optical Mouse', 1100, 12, 'fgt', '.........................', '...................', 'product_images/1457949437702761.jpg', 1, 0),
(119, 14, 13, 'Optical Mouse', 1050, 78, 'hyu', '..................', '..........................', 'product_images/233137080_48adae47-1f80-45fb-b44b-64f7f082fed2.jpg', 1, 0),
(120, 14, 13, 'Optical Mouse', 700, 147, 'lllv', '...............', '.......................', 'product_images/9339028013086.jpg', 1, 0),
(121, 14, 13, 'Optical Mouse', 850, 17, 'yt', '.................', '...............', 'product_images/61HhRdHCudL._SL1500_-e1493831350108.jpg', 1, 0),
(122, 14, 13, 'Optical Mouse', 1200, 15, 'tr.', '....................', '......................', 'product_images/ROCCAT_Kone_Pure_Optical_01.jpg', 1, 0),
(123, 14, 13, 'Optical Mouse', 600, 78, 'bvfg', '....................', '.................', 'product_images/cougar-450m-top-view-2-800x533-c.jpg', 1, 0),
(124, 14, 13, 'Optical Mouse', 550, 76, 'fgtr', '.................', '.....................', 'product_images/roccat-kone-plus-gaming-mouse-image.jpg', 1, 0),
(125, 14, 13, 'Optical Mouse', 500, 19, 'vgf', '.................', '...........................', 'product_images/Speedlink-Prime-Z-DW-Featured.jpg', 1, 0),
(126, 16, 15, 'Rosewill RLCP-11004 Laptop Cooling Pad', 3300, 56, 'gty', '...................', '................', 'product_images/34-981-023-02.jpg', 1, 0),
(127, 16, 15, 'Rosewill RLCP-11 Laptop Cooling Pad', 1200, 59, 'lpo', '.....................', '..................', 'product_images/NotepalXLfront_01.jpg', 1, 0),
(128, 16, 15, 'Rosewill RLCP-3404 Laptop Cooling Pad', 1800, 23, 'ed', '..............................', '.................................', 'product_images/qw.jpg', 1, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_product`
--
ALTER TABLE `tbl_product`
  ADD PRIMARY KEY (`product_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_product`
--
ALTER TABLE `tbl_product`
  MODIFY `product_id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=129;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
