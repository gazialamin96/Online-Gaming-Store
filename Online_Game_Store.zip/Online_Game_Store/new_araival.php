<div class="clearfix">
			<h2 class="color_dark tt_uppercase f_left m_bottom_15 f_mxs_none heading5 animate_ftr">New Araivals</h2>
			<div class="f_right clearfix nav_buttons_wrap animate_fade f_mxs_none m_mxs_bottom_5">
				<button class="button_type_7 bg_cs_hover box_s_none f_size_ex_large t_align_c bg_light_color_1 f_left tr_delay_hover r_corners nc_prev"><i class="fa fa-angle-left"></i></button>
				<button class="button_type_7 bg_cs_hover box_s_none f_size_ex_large t_align_c bg_light_color_1 f_left m_left_5 tr_delay_hover r_corners nc_next"><i class="fa fa-angle-right"></i></button>
			</div>
		</div>
		<!--bestsellers carousel-->
		<div class="nc_carousel m_bottom_30 m_sm_bottom_20">
			<figure class="r_corners photoframe animate_ftb long tr_all_hover type_2 t_align_c shadow relative">
				<!--product preview-->
				<a href="#" class="d_block relative pp_wrap m_bottom_15">
					<!--hot product-->
					<span class="hot_stripe type_2"><img src="" alt=""></span>
					<img src="asset/frontend/images/product_img_5.jpg" class="tr_all_hover" alt="">
					
				</a>
				<!--description and price of product-->
				<figcaption class="p_vr_0">
				<h5 class="m_bottom_10"><a href="#" class="color_dark">Aliquam erat volutpat</a></h5>
				<div class="clearfix">
					
					<p class="scheme_color f_size_large m_bottom_15">৳2000</p>
				</div>
				<!-- <button class="button_type_4 bg_scheme_color r_corners tr_all_hover color_light mw_0 m_bottom_15">Add to Cart</button> -->
				<!-- <div class="clearfix m_bottom_5">
					<ul class="horizontal_list d_inline_b l_width_divider">
						<li class="m_right_15 f_md_none m_md_right_0"><a href="#" class="color_dark">Add to Wishlist</a></li>
						<li class="f_md_none"><a href="#" class="color_dark">Add to Compare</a></li>
					</ul>
				</div> -->
				</figcaption>
			</figure>
			
			<figure class="r_corners photoframe animate_ftb long tr_all_hover type_2 t_align_c shadow relative">
				<!--product preview-->
				<a href="#" class="d_block relative pp_wrap m_bottom_15">
					<img src="asset/frontend/images/product_img_8.jpg" class="tr_all_hover" alt="">
					
				</a>
				<!--description and price of product-->
				<figcaption class="p_vr_0">
				<h5 class="m_bottom_10"><a href="#" class="color_dark">Aliquam erat volutpat</a></h5>
				<div class="clearfix">
					
				
					<p class="scheme_color f_size_large m_bottom_15">৳10000</p>
				</div>
			<!-- 	<button class="button_type_4 bg_scheme_color r_corners tr_all_hover color_light mw_0 m_bottom_15">Add to Cart</button> -->
				<!-- <div class="clearfix m_bottom_5">
					<ul class="horizontal_list d_inline_b l_width_divider">
						<li class="m_right_15 f_md_none m_md_right_0"><a href="#" class="color_dark">Add to Wishlist</a></li>
						<li class="f_md_none"><a href="#" class="color_dark">Add to Compare</a></li>
					</ul>
				</div> -->
				</figcaption>
			</figure>
			<figure class="r_corners photoframe animate_ftb long type_2 t_align_c shadow relative tr_all_hover">
				<!--product preview-->
				<a href="#" class="d_block relative pp_wrap m_bottom_15">
					<!--sale product-->
					<span class="hot_stripe type_2"><img src="asset/frontend/images/sale_product_type_2.png" alt=""></span>
					<img src="asset/frontend/images/product_img_4.jpg" class="tr_all_hover" alt="">
					
				</a>
				<!--description and price of product-->
				<figcaption class="p_vr_0">
				<h5 class="m_bottom_10"><a href="#" class="color_dark">Ut tellus dolor dapibus</a></h5>
				<div class="clearfix m_bottom_15">
					
					
					<p class="scheme_color f_size_large">৳5700</p>
				</div>
				<!-- <button class="button_type_4 bg_scheme_color r_corners tr_all_hover color_light mw_0 m_bottom_15">Add to Cart</button> -->
				<!-- <div class="clearfix m_bottom_5">
					<ul class="horizontal_list d_inline_b l_width_divider">
						<li class="m_right_15 f_md_none m_md_right_0"><a href="#" class="color_dark">Add to Wishlist</a></li>
						<li class="f_md_none"><a href="#" class="color_dark">Add to Compare</a></li>
					</ul>
				</div> -->
				</figcaption>
			</figure>
			
		</div>
		<!--product brands-->
		<div class="clearfix m_bottom_25 m_sm_bottom_20">
			<h2 class="tt_uppercase color_dark f_left heading2 animate_fade f_mxs_none m_mxs_bottom_15">Product Brands</h2>
			<div class="f_right clearfix nav_buttons_wrap animate_fade f_mxs_none">
				<button class="button_type_7 bg_cs_hover box_s_none f_size_ex_large t_align_c bg_light_color_1 f_left tr_delay_hover r_corners pb_prev"><i class="fa fa-angle-left"></i></button>
				<button class="button_type_7 bg_cs_hover box_s_none f_size_ex_large t_align_c bg_light_color_1 f_left m_left_5 tr_delay_hover r_corners pb_next"><i class="fa fa-angle-right"></i></button>
			</div>
		</div>
		
		<!--product brands carousel-->
		<div class="product_brands with_sidebar m_sm_bottom_35">
			<?php
			while ($row=mysql_fetch_assoc($result)) {
			
			?>
			<a href="?option=manufacturer&manufacturer_id=<?php echo $row['manufacturer_id']?>" class="d_block t_align_c animate_fade">
				<h3><?php echo $row['manufacturer_name']?></h3>
			</a>
			
			<?php }?>
		</div>