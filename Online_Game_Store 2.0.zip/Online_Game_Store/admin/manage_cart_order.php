<?php
    $page = 'manage_cart_order_info.php';
    include './dashboard.php';

?>