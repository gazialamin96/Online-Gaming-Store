<?php 
    $manufacturer_id=$_GET['id'];
    $page = 'edit_manufacturer_form.php';
    include 'dashboard.php';

?>