<?php
    $page = 'view_order_products.php';
    include 'dashboard.php';
 ?>
 