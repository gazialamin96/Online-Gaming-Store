<?php
    $page = 'manage_catagory_info.php';
    include './dashboard.php';

?>