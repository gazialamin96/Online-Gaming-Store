<?php
    $page = 'manage_product_info.php';
    include './dashboard.php';

?>